from django.shortcuts import render
from django.http import HttpResponse

from django.template import loader #for template
# Create your views here.

def index(request):
    t=loader.get_template('home.html')
    stat="welcome to home page"
    #stat=None
    items=['Coffee','Tea','U.Vada','P.Vada',
    'Sandvich','Paratta','Dosa','Idly']
    #m1=[{'Coffee':10,'Tea':10}]
    m1=[{'name':i,'price':10} for i in items]
    return HttpResponse(t.render({'msg':stat,'menu':items,'itms':m1},request))
    #return HttpResponse("Welcome to My Page")

def about(request):
    return HttpResponse("About us..!")

def services(request):
    return HttpResponse("Our service..")

def contact(request):
    return HttpResponse("<b>Contact us..!</b>")
